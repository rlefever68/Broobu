using System;
using DevExpress.Mvvm;

namespace DxNavigationControl.ViewModels
{
    public class ViewModel : ViewModelBase
    {
    }
}