using System;
using DevExpress.Mvvm;

namespace DxNavigationControl.ViewModels
{
    public class StartViewModel : ViewModel
    {
        
    }
}