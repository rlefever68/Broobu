using System;
using DevExpress.Mvvm;

namespace DxNavigation.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
    }
}